﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Structure
{
    struct Books
    {
        public string title;
        public string bookType;
        public int price;
        public int book_id;


   
    
        public void GET()
        {
            Console.WriteLine("enter no.of books");
            int size = int.Parse(Console.ReadLine());
            Books[] books = new Books[size];
            for (int i = 0; i < books.Length; i++)

                Console.WriteLine("Title: {0}", title);
           Console.WriteLine("book-price: {0}", price);
           Console.WriteLine("bookType: {0}", bookType);
          Console.WriteLine("Book_id: {0}", book_id);
        }

    }
   public class book2

   {   // public object book2(AttributeTargets(),private AppDomainSetup())
        enum bookType { Magazine, Novel, ReferenceBook, Miscellaneous };

        public static void Main(string[] args)
        {
            string bookType = (string)Console.ReadLine();


            book2[] Books = new book2[price];
             Book2 = new book2;


            /*Book 1 detailing */
             Book1.Book;

            /*Book 2 DETAILED DESCRIPTION */
            Book2.BOOK​ ​​;

            /*Print Book1 information */
            Book1.GET();

            /*Print Book2 information */
            Book2.GET();

            Console.ReadKey();

        }
    }
}

   

