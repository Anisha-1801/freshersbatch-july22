﻿using System;
using Class_1;
using class_2;
using class_3swap;
using class4;
using cir_and_area;


namespace Calculator
{
     class Program
    {
        static void Main(string[] args)
        {
            // Declare variables and then initialize to zero.
            int num1 = 0; int num2 = 0;

            
            Console.WriteLine("Console Calculator in C#\r");
            Console.WriteLine("------------------------\n");

          
            Console.WriteLine("ENTER YOUR FIRST NUMBER : ");
            num1 = Convert.ToInt32(Console.ReadLine());

           
            Console.WriteLine("ENTER YOUR SECOND NUMBER : ");
            num2 = Convert.ToInt32(Console.ReadLine());

            
            Console.WriteLine("Choose an option from the following list:");
            Console.WriteLine("\tAdd + ");
            Console.WriteLine("\tSubtract - ");
            Console.WriteLine("\tMultiply * ");
            Console.WriteLine("\tDivide / ");
            Console.Write("Your option? ");

           
            switch (Console.ReadLine())
            {
                case "+":
                    Console.WriteLine($"Your result: {num1} + {num2} = " + (num1 + num2));
                    break;
                case "-":
                    Console.WriteLine($"Your result: {num1} - {num2} = " + (num1 - num2));
                    break;
                case "*":
                    Console.WriteLine($"Your result: {num1} * {num2} = " + (num1 * num2));
                    break;
                case "/":
                    Console.WriteLine($"Your result: {num1} / {num2} = " + (num1 / num2));
                    break;
            }
            Class1.Method();
            Class2.Mains();
            Class2.Sum();
            swapno.Main();
            areandcir.areandcir2();
            Book.Details();









            Console.Write("Press any key to close the Calculator console app...");
            Console.ReadKey();
        }
    }
}

