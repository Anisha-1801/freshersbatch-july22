﻿using System;


namespace Class_1
{
    public class Class1
    {
        public static void Method()
        {
            {
                Console.WriteLine("Enter average marks of 5 students:");
                double S1 = double.Parse(Console.ReadLine());
                double S2 = double.Parse(Console.ReadLine());
                double S3 = double.Parse(Console.ReadLine());
                double S4 = double.Parse(Console.ReadLine());
                double S5 = double.Parse(Console.ReadLine());

                if ((S1 >= S2) && (S1 >= S3) && (S1 >= S4) && (S1>= S5))
                {
                    Console.WriteLine("The biggest number is: {0}", S1);
                    return;
                }
                if ((S2 >= S1) && (S2 >= S3) && (S2 >= S4) && (S2 >= S5))
                {
                    Console.WriteLine("The biggest number is: {0}", S2);
                    return;
                }
                if ((S3 >= S1) && (S3 >= S2) && (S3 >= S4) && (S3 >= S5))
                {
                    Console.WriteLine("The biggest number is: {0}", S3);
                    return;
                }
                if ((S4 >= S1) && (S4 >= S2) && (S4 >= S3) && (S4 >= S5))
                {
                    Console.WriteLine("The biggest number is: {0}", S4);
                    return;
                }
                if ((S5 >= S1) && (S5 >= S2) && (S5 >= S3) && (S5 >= S4))
                {
                    Console.WriteLine("The biggest number is: {0}", S5);
                    return;
                }

            }

        }
    }
}


