﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace class_2
{
    public class Class2
    {

        public static void Mains()
        {
            try
            {
                Console.WriteLine("ENTER  VALUES OF SIZE");
                int size = Convert.ToInt32(Console.ReadLine());
                Class2.Sum(new int[size]);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.GetType().Name);
            }

        }
        public static void Sum(params int[] values)
        {
            Console.WriteLine("ENTER  VALUES OF ARRAY ");
            for (int i = 0; i < values.Length; i++)
            {
                values[i] = Convert.ToInt32(Console.ReadLine());
            }
            int totalsum = values.Sum();
            Console.WriteLine("totalsum ={0}", totalsum);
        }
    }
}
