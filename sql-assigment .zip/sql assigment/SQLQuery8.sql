use[Assignment]
go
CREATE TABLE Employee  
(  
EmployeeID int,  
FirstName nvarchar(40),  
LastName nvarchar(40),  
Manager nvarchar(40),  
Dept_name nvarchar(50),  
Rating nvarchar(5),  
DOJ datetime not null
)
select * from Employee
insert into Employee (EmployeeID,FirstName,LastName,Manager,Dept_name,Rating,DOJ) values (1,'Riya','Soni','Mrs.Patel','ANALYST','4','7-11-2019')
insert into Employee (EmployeeID,FirstName,LastName,Manager,Dept_name,Rating,DOJ) values (2,'Steven ',' King ','Mrs.bawa','HR','2','1987-06-17')
insert into Employee (EmployeeID,FirstName,LastName,Manager,Dept_name,Rating,DOJ) values (3,'Neena ','Kochhar','Mrs.dvd','ANALYST','3','7-12-2022')
insert into Employee (EmployeeID,FirstName,LastName,Manager,Dept_name,Rating,DOJ) values (4,'Mike','Lopez','Mr Adams','SALES','1','7-01-2020')
insert into Employee (EmployeeID,FirstName,LastName,Manager,Dept_name,Rating,DOJ) values (5,'Riya','Soni','Mr Allen','HR','2','1987-06-23')

SELECT  FirstName,LastName, 
              FirstName + ' ' + LastName AS FullName
FROM Employee

SELECT  FirstName,LastName,Manager FROM Employee order by Manager

select Dept_name,Rating from Employee
SELECT *
FROM Employee 
ORDER BY DOJ ASC;
SELECT *
FROM Employee 
ORDER BY DOJ DESC;


