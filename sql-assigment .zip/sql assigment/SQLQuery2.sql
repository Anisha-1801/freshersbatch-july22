CREATE DATABASE ASSIGNMENT
use [Assignment]
go
create table Customer
(
ID int not null primary key,
FirstName nvarchar(40) NOT NULL ,
LastName nvarchar(40),
City nvarchar(40),
Country nvarchar(40),
Phone nvarchar(20)
)
select * from Customer
insert into Customer (ID,FirstName,LastName,Country,City,Phone) values (1,'AMISHKA','KHOLI','Mumbai','India','919')
insert into Customer (ID,FirstName,LastName,Country,City,Phone) values (2,'DVIYA','Jain','France','Lyon','818')
insert into Customer (ID,FirstName,LastName,Country,City,Phone) values (3,'SUSH','Roy','Germany','Berlin','759')
insert into Customer (ID,FirstName,LastName,Country,City,Phone) values (4,'ISHIKA','PATEL','Canada','Tornto','506')
select * from Customer where Country like 'A%' or Country like 'I%'
select * from Customer where FirstName like '__i%'; 
select * from Customer where Country ='Germany';
UPDATE Customer
SET Country = 'Germany', City= 'Berlin'
WHERE ID = 3

SELECT Supplier.FaxNumber, Customer.FirstName
FROM Customer
INNER JOIN Supplier
ON Customer.ID=Supplier.ID;
insert into Customer (ID,FirstName,LastName,City,Country,Phone) values (5,'abc','xyz','Canada','Tornto','000')
insert into Customer (ID,FirstName,LastName,City,Country,Phone) values (6,'def','efg','Canada','Tornto','000')
UPDATE Customer
SET Phone = '030-0074321'
WHERE ID = 1
select Customer.[Firstname],Customer.[Phone],Orders.[OrderNumber]
from Customer
inner join Orders
on Customer.ID=Orders.ID
where Phone = '030-0074321'



select Customer.[Firstname],Customer.[Phone],Customer.[City],Orders.[OrderNumber]
from Customer
inner join Orders
on Customer.ID=Orders.ID
where city <> 'london'
 