use ASSIGNMENT
go
cREATE TABLE Orders
(
ID int not null primary key,
OrderDate datetime not null ,
OrderNumber nvarchar(10),
CUSTOMERID int,
TotalAmount decimal(12,2)
)
select * from Orders
insert into Orders (ID,OrderDate,OrderNumber,CUSTOMERID,TotalAmount) values (1,'1-1-2022','5021','1','3333.0')
insert into Orders (ID,OrderDate,OrderNumber,CUSTOMERID,TotalAmount) values (2,'3-4-2022','3424','2','6666.0')
insert into Orders (ID,OrderDate,OrderNumber,CUSTOMERID,TotalAmount) values (3,'6-6-2022','3136','3','8956.3')
insert into Orders (ID,OrderDate,OrderNumber,CUSTOMERID,TotalAmount) values (4,'7-7-2022','8249','4','7348.5')
delete from orders where id=4

alter table Orders
add Shippingdate datetime
alter table Orders
add Shippingname nvarchar(20)

insert into Orders (ID,OrderDate,OrderNumber,CUSTOMERID,TotalAmount,Shippingdate,Shippingname) values (5,'7-24-2019','2256','5','7000.0','8-2-2019','La come dabondance')
insert into Orders (ID,OrderDate,OrderNumber,CUSTOMERID,TotalAmount,Shippingdate,Shippingname) values (6,'7-24-2020','3658','6','6000.0','8-2-2020','La come dabondance')


SELECT OrderDate , Shippingdate
FROM  Orders
ORDER BY OrderDate , Shippingdate  ;


UPDATE Orders
SET  Shippingdate=7-24-2018
WHERE ID = 4
select * from Orders where Shippingname = 'La come dabondance' and Shippingdate between '7-24-2018' and '7-24-2020'
alter table Orders
add Operational bit
UPDATE Orders
SET  Operational=1
WHERE ID = 5
UPDATE Orders
SET  Operational=0
WHERE ID = 6

select Shippingname ,Operational from Orders where Operational = 1 or Operational =0

SELECT Product.Suppliers,Orders.[TotalAmount],Orders.[Shippingname] FROM Orders
INNER JOIN Product ON Orders.[ID]=Product.[Id]
WHERE  Product.Suppliers = 'EXOTIC LIQUIDS' AND Orders.[TotalAmount] >50

SELECT * FROM CUSTOMER WHERE SUBSTRING([FirstName],1,2)='RA'

SELECT CONCAT(CUSTOMER.[FIRSTNAME],' ',CUSTOMER.[LASTNAME]) AS [CUSTOMERNAME],ORDERITEM.QUANTITY AS [NO.OF ORDERS] FROM ORDERITEM
INNER JOIN [Orders]  ON [Orders] .[ID]=ORDERITEM.[ORDERID]
INNER JOIN CUSTOMER ON CUSTOMER.[ID]=[Orders].[ID]
WHERE ORDERITEM.QUANTITY=(SELECT MAX(QUANTITY) FROM ORDERITEM)