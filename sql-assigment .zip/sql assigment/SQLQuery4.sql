select * from Customer
select * from Orders
select * from Product
select * from OrderItem
select * from Supplier


ALTER TABLE [OrderItem] 
ADD CONSTRAINT FK_OrderId FOREIGN KEY (OrderId) 
    REFERENCES  Orders(Id)


	ALTER TABLE [OrderItem] 
ADD CONSTRAINT FK2_ProductId FOREIGN KEY (ProductId) 
    REFERENCES  Product(Id)

ALTER TABLE orders 
ADD CONSTRAINT FK_customer
FOREIGN KEY (CUSTOMERID) REFERENCES customer (ID)

select * from Customer where Country like 'A%' or Country like 'I%'

select * from Customer where FirstName like '__i%'; 

SELECT * FROM  Customer
WHERE Country='Germany';


select * from Customer where FirstName like '_u%'; 

