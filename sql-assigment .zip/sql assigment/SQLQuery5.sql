use assignment
go
create table OrderItem
(
ID int not null primary key ,
OrderId int ,
ProductId int ,
UnitPrice decimal (12,2),
QUANTITY INT

)
select * from OrderItem
insert into OrderItem (ID,OrderId,ProductId,UnitPrice,QUANTITY) values (1,1,11,14.00,12)
insert into OrderItem (ID,OrderId,ProductId,UnitPrice,QUANTITY) values (2,1,42,9.80,10)
insert into OrderItem (ID,OrderId,ProductId,UnitPrice,QUANTITY) values (3,1,72,34.80,5)
insert into OrderItem (ID,OrderId,ProductId,UnitPrice,QUANTITY) values (4,2,51,42.40,40)
insert into OrderItem (ID,OrderId,ProductId,UnitPrice,QUANTITY) values (6,3,41,7.70,10)
UPDATE OrderItem
SET  ID=5
WHERE OrderId = 3
UPDATE OrderItem
SET  ProductId=1
WHERE ID = 1
UPDATE OrderItem
SET  ProductId=1
WHERE ID = 1
UPDATE OrderItem
SET  ProductId=2
WHERE ID = 2
UPDATE OrderItem
SET  ProductId=3
WHERE ID = 3
UPDATE OrderItem
SET  ProductId=4
WHERE ID = 4
UPDATE OrderItem
SET  ProductId=5
WHERE ID = 5

ALTER TABLE [OrderItem] 
ADD CONSTRAINT FK_OrderId FOREIGN KEY (OrderId) 
    REFERENCES  Orders(Id)


ALTER TABLE [OrderItem] 
ADD CONSTRAINT FK_ProductId
FOREIGN KEY (ProductId) REFERENCES Product(Id)

select UnitPrice from OrderItem where UnitPrice > 10 and UnitPrice < 20


SELECT AVG(QUANTITY) AS AVERAGE,[ProductId] FROM OrderItem GROUP BY [ProductId]


SELECT OrderItem.[ID],Product.[ProductName],Product.Categoryname,[Product].[discount] FROM OrderItem
INNER JOIN [Orders ] ON [Orders ].[ID]=OrderItem.[ID]
INNER JOIN Product ON Product.[Id]=OrderItem.[ID] 
WHERE OrderItem.[ID]= 1